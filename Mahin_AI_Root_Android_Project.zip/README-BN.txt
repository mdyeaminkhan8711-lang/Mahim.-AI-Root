Mahin AI Root — Android APK project

এই প্রজেক্টটি আপনার দেওয়া ওয়েব অ্যাপটিকে Android WebView অ্যাপ হিসেবে প্যাকেজ করে।
এটি কেবল UI/প্রাথমিক সংস্করণ। AI ROOT বোতাম ফোন রুট করে না এবং system/boot/kernel বদলায় না।

APK বানানোর সহজ পথ (GitHub Actions):
1. ZIP ফাইলটি Extract করুন।
2. GitHub-এ নতুন Public বা Private repository তৈরি করুন।
3. Extract করা ফোল্ডারের ভেতরের সব ফাইল ও ফোল্ডার repository-তে upload করুন (ZIP-টিকে একা upload করবেন না)।
4. Commit changes করুন।
5. Actions tab খুলুন। "Build Mahin AI Root APK" workflow চলবে।
6. Workflow সফল হলে run খুলে নিচের Artifacts থেকে "Mahin-AI-Root-APK" ডাউনলোড করুন।
7. ZIP artifact extract করলে app-debug.apk পাবেন। Android-এ ইনস্টল করতে চাইলে অনুমতি চাইলে Allow করুন।

নোট: GitHub account প্রয়োজন। APK debug-signed; Play Store release-এর জন্য নয়।
