Mahin AI Root — প্রাথমিক নিরাপদ সংস্করণ

এটি এখন একটি অফলাইন-সক্ষম ওয়েব অ্যাপ (PWA) প্রোটোটাইপ, Android APK নয়।
ব্যবহার:
1. ZIP ফাইলটি Extract করুন।
2. index.html Chrome-এ খুলে দেখুন।
3. হোম স্ক্রিনে ইনস্টল করতে ওয়েবসাইটটি HTTPS-এ হোস্ট করতে হবে; তারপর Chrome মেনু থেকে Install app / Add to Home screen ব্যবহার করুন।

AI ROOT বাটনটি এখন শুধু নিরাপদ placeholder। এটি ফোনে Root দেয় না এবং system/boot/kernel পরিবর্তন করে না।
আপনার ফোনের Kernel 4.9.227-এর জন্য নিশ্চিতভাবে compatible ও নিরাপদ Root পদ্ধতি যাচাই না হওয়া পর্যন্ত প্রকৃত Root চালু করা হবে না।
